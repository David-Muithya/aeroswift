package com.airlinesystem;

import com.airlinesystem.utils.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookingHistoryPage extends JFrame {
    private int userId;

    public BookingHistoryPage(int userId) {
        this.userId = userId;
        setTitle("Booking History");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JTextArea bookingArea = new JTextArea();
        bookingArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(bookingArea);
        JButton backButton = new JButton("Back");

        add(scrollPane, BorderLayout.CENTER);
        add(backButton, BorderLayout.SOUTH);

        backButton.addActionListener(e -> {
            dispose();
            new Dashboard(userId).setVisible(true);
        });

        loadBookingHistory(bookingArea);

        setLocationRelativeTo(null);
    }

    private void loadBookingHistory(JTextArea bookingArea) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM bookings WHERE user_id = ?")) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                bookingArea.append("Booking ID: " + rs.getInt("id") + "\n");
                bookingArea.append("Flight: " + rs.getString("flight_number") + "\n");
                bookingArea.append("Date: " + rs.getString("date") + "\n\n");
            }
        } catch (SQLException e) {
            bookingArea.setText("Error loading booking history: " + e.getMessage());
        }
    }
}
