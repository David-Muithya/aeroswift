package com.airlinesystem;

import com.airlinesystem.utils.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PaymentPage extends JFrame {
    private int userId;
    private int flightId;

    public PaymentPage(int userId, int flightId) {
        this.userId = userId;
        this.flightId = flightId;
        setTitle("Payment");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 1));

        JTextField paymentField = new JTextField("Enter payment amount");
        JButton payButton = new JButton("Pay Now");
        JButton backButton = new JButton("Back");

        add(paymentField);
        add(payButton);
        add(backButton);

        payButton.addActionListener(e -> processPayment(paymentField.getText()));
        backButton.addActionListener(e -> {
            dispose();
            new BookingConfirmationPage(userId, flightId).setVisible(true);
        });

        setLocationRelativeTo(null);
    }

    private void processPayment(String paymentAmount) {
        try {
            double amount = Double.parseDouble(paymentAmount);
            // Simulate successful payment process
            JOptionPane.showMessageDialog(this, "Payment successful!");

            // Add booking to the database
            addBookingToHistory();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid payment amount.");
        }
    }

    private void addBookingToHistory() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO bookings (user_id, flight_id) VALUES (?, ?)")) {
            stmt.setInt(1, userId);
            stmt.setInt(2, flightId);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Booking successful!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error confirming booking: " + e.getMessage());
        }
    }
}
