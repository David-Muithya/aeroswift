package com.airlinesystem;

import com.airlinesystem.utils.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.event.ActionListener;
import javax.swing.table.TableCellRenderer;

public class FlightSearchPage extends JFrame {
    private final int userId;  // Marked as final as it's not reassigned
    private final JTextField departureField;  // Departure airport input field
    private final JTextField arrivalField;    // Arrival airport input field
    private final JTextField dateField;       // Travel date input field
    private final JTable resultTable;         // JTable to display search results

    public FlightSearchPage(int userId) {
        this.userId = userId;
        setTitle("Search Flights");
        setSize(800, 400); // Adjusted the size for the table
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel for input fields
        JPanel inputPanel = new JPanel(new GridLayout(4, 2));  // Added 4 rows for inputs
        inputPanel.add(new JLabel("Departure Airport:"));
        departureField = new JTextField();
        inputPanel.add(departureField);

        inputPanel.add(new JLabel("Arrival Airport:"));
        arrivalField = new JTextField();
        inputPanel.add(arrivalField);

        inputPanel.add(new JLabel("Travel Date (YYYY-MM-DD):"));
        dateField = new JTextField();
        inputPanel.add(dateField);

        JButton searchButton = new JButton("Search");
        JButton backButton = new JButton("Back");
        inputPanel.add(searchButton);
        inputPanel.add(backButton);

        add(inputPanel, BorderLayout.NORTH);

        // JTable for displaying results
        resultTable = new JTable();
        resultTable.setDefaultEditor(Object.class, null);  // Disable editing of cells
        JScrollPane scrollPane = new JScrollPane(resultTable);
        add(scrollPane, BorderLayout.CENTER);

        // Search button action listener
        searchButton.addActionListener(e -> searchFlights());

        // Back button action listener
        backButton.addActionListener(e -> {
            dispose();
            new Dashboard(userId).setVisible(true);
        });

        setLocationRelativeTo(null);
    }

    private void searchFlights() {
        String departure = departureField.getText();
        String arrival = arrivalField.getText();
        String travelDate = dateField.getText();  // Get the travel date input

        // SQL query to fetch flight details with correct column names
        String sqlQuery = "SELECT f.id, f.flight_number, a1.name AS departure_airport, a2.name AS arrival_airport, " +
                "f.departure_time, f.arrival_time, f.cost " +
                "FROM flights f " +
                "JOIN airports a1 ON f.departure_airport_id = a1.id " +
                "JOIN airports a2 ON f.arrival_airport_id = a2.id " +
                "WHERE a1.name LIKE ? AND a2.name LIKE ? AND DATE(f.departure_time) = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sqlQuery)) {

            stmt.setString(1, "%" + departure + "%");
            stmt.setString(2, "%" + arrival + "%");
            stmt.setString(3, travelDate);
            ResultSet rs = stmt.executeQuery();

            // Table model to hold data
            DefaultTableModel model = new DefaultTableModel(new Object[]{"Flight Number", "Departure", "Arrival",
                    "Departure Time", "Arrival Time", "Price", "Book"}, 0);

            while (rs.next()) {
                // Fetch flight data
                String flightNumber = rs.getString("flight_number");
                String depAirport = rs.getString("departure_airport");
                String arrAirport = rs.getString("arrival_airport");
                String depTime = rs.getString("departure_time");
                String arrTime = rs.getString("arrival_time");
                double price = rs.getDouble("cost");
                int flightId = rs.getInt("id");

                // Add row to model with flight details
                model.addRow(new Object[]{flightNumber, depAirport, arrAirport, depTime, arrTime, "$" + price, flightId});
            }

            // Set the model to the table
            resultTable.setModel(model);

            // Add a custom button renderer to the last column ("Book")
            TableColumn bookColumn = resultTable.getColumn("Book");
            bookColumn.setCellRenderer(new ButtonRenderer());
            bookColumn.setCellEditor(new ButtonEditor(new JCheckBox(), userId));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error searching flights: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Custom renderer for the "Book" button
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setText("Book");
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
                                                       int row, int column) {
            return this;
        }
    }

    // Custom editor for the "Book" button
    class ButtonEditor extends DefaultCellEditor {
        private final int userId;
        private JButton button;
        private int flightId;

        public ButtonEditor(JCheckBox checkBox, int userId) {
            super(checkBox);
            this.userId = userId;
            button = new JButton("Book");
            button.addActionListener(e -> bookFlight(flightId));
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            flightId = (Integer) table.getValueAt(row, 6);  // Get the flightId from the last column (which contains the flightId)
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            return "Book"; // Just return a placeholder text for consistency
        }
    }

    private void bookFlight(int flightId) {
        new BookingConfirmationPage(userId, flightId).setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        // Assuming userId is 1 for demonstration purposes
        new FlightSearchPage(1).setVisible(true);
    }
}
