package com.airlinesystem;

import com.airlinesystem.utils.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfileManagementPage extends JFrame {
    private int userId;

    public ProfileManagementPage(int userId) {
        this.userId = userId;
        setTitle("Manage Profile");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2));

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();
        JButton saveButton = new JButton("Save");
        JButton backButton = new JButton("Back");

        add(nameLabel);
        add(nameField);
        add(emailLabel);
        add(emailField);
        add(saveButton);
        add(backButton);

        loadProfileDetails(nameField, emailField);

        saveButton.addActionListener(e -> saveProfile(nameField, emailField));
        backButton.addActionListener(e -> {
            dispose();
            new Dashboard(userId).setVisible(true);
        });

        setLocationRelativeTo(null);
    }

    private void loadProfileDetails(JTextField nameField, JTextField emailField) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT name, email FROM users WHERE id = ?")) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                nameField.setText(rs.getString("name"));
                emailField.setText(rs.getString("email"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading profile: " + e.getMessage());
        }
    }

    private void saveProfile(JTextField nameField, JTextField emailField) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE users SET name = ?, email = ? WHERE id = ?")) {
            stmt.setString(1, nameField.getText());
            stmt.setString(2, emailField.getText());
            stmt.setInt(3, userId);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Profile updated successfully!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error saving profile: " + e.getMessage());
        }
    }
}
