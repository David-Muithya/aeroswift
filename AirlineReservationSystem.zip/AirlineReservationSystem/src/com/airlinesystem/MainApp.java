package com.airlinesystem;

import javax.swing.*;
import java.awt.*;

public class MainApp extends JFrame {
    public MainApp() {
        setTitle("Airline Reservation System");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 1));

        JLabel welcomeLabel = new JLabel("Welcome to Airline Reservation System", SwingConstants.CENTER);
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        add(welcomeLabel);
        add(loginButton);
        add(registerButton);

        loginButton.addActionListener(e -> {
            dispose();
            new LoginPage().setVisible(true);
        });

        registerButton.addActionListener(e -> {
            dispose();
            new RegisterPage().setVisible(true);
        });

        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainApp().setVisible(true));
    }
}
