package com.airlinesystem;

import javax.swing.*;
import java.awt.*;

public class Dashboard extends JFrame {
    private int userId;

    public Dashboard(int userId) {
        this.userId = userId;
        setTitle("Dashboard");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        JLabel welcomeLabel = new JLabel("Welcome to your Dashboard", SwingConstants.CENTER);
        JButton viewBookingsButton = new JButton("View Booking History");
        JButton searchFlightButton = new JButton("Search Flights");
        JButton manageProfileButton = new JButton("Manage Profile");

        add(welcomeLabel);
        add(viewBookingsButton);
        add(searchFlightButton);
        add(manageProfileButton);

        viewBookingsButton.addActionListener(e -> {
            dispose();
            new BookingHistoryPage(userId).setVisible(true);
        });

        searchFlightButton.addActionListener(e -> {
            dispose();
            new FlightSearchPage(userId).setVisible(true);
        });

        manageProfileButton.addActionListener(e -> {
            dispose();
            new ProfileManagementPage(userId).setVisible(true);
        });

        setLocationRelativeTo(null);
    }
}
