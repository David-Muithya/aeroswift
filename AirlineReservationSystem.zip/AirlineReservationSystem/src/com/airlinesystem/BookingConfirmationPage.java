package com.airlinesystem;

import com.airlinesystem.utils.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookingConfirmationPage extends JFrame {
    private int userId;
    private int flightId;

    public BookingConfirmationPage(int userId, int flightId) {
        this.userId = userId;
        this.flightId = flightId;
        setTitle("Booking Confirmation");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        JTextArea flightDetailsArea = new JTextArea();
        flightDetailsArea.setEditable(false);
        JButton confirmButton = new JButton("Confirm Booking");
        JButton backButton = new JButton("Back");

        add(flightDetailsArea);
        add(confirmButton);
        add(backButton);

        loadFlightDetails(flightDetailsArea);

        confirmButton.addActionListener(e -> confirmBooking());
        backButton.addActionListener(e -> {
            dispose();
            new FlightSearchPage(userId).setVisible(true);
        });

        setLocationRelativeTo(null);
    }

    private void loadFlightDetails(JTextArea flightDetailsArea) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM flights WHERE id = ?")) {
            stmt.setInt(1, flightId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                flightDetailsArea.append("Flight Number: " + rs.getString("flight_number") + "\n");
                flightDetailsArea.append("Destination: " + rs.getString("destination") + "\n");
                flightDetailsArea.append("Date: " + rs.getString("date") + "\n");
                flightDetailsArea.append("Price: " + rs.getDouble("price") + "\n");
            }
        } catch (SQLException e) {
            flightDetailsArea.setText("Error loading flight details: " + e.getMessage());
        }
    }

    private void confirmBooking() {
        new PaymentPage(userId, flightId).setVisible(true);
        dispose();
    }
}
